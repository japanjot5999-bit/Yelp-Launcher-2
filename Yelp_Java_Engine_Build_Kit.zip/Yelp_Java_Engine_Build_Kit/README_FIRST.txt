YELP JAVA ENGINE COMPANION BUILD KIT

This is the GitHub Actions build recipe for the separate Amethyst-based Java Edition
engine companion APK. It is NOT the Amethyst engine source tree and it is NOT an APK.

The workflow checks out the upstream Amethyst-Android project and its submodules during
GitHub Actions, downloads the Java 8 runtime build asset, and builds the companion APK.
The engine source is therefore fetched from its upstream project during the build.

Output artifact name: Yelp-Java-Engine-Amethyst-debug-apk

To use this package in GitHub, preserve the .github/workflows/android-engine.yml path.
