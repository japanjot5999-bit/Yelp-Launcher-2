# Install and connect the Java Edition engine

The current 0.6.0-alpha project uses two Android APKs because the Amethyst Java engine is a full application, not a drop-in library. This creates a real app-to-app route to the engine, not an embedded Java runtime inside Yelp.

1. Push this project ZIP's extracted contents to your GitHub repository.
2. Open **Actions → Yelp Launcher and Java Engine APKs** and run the workflow.
3. Download both artifacts from the completed workflow:
   - `Yelp-Launcher-0.6.0-alpha-debug-apk`
   - `Yelp-Java-Engine-Amethyst-debug-apk`
4. Install the Amethyst engine companion APK first, then install Yelp Launcher. Android may ask you to allow installation from the browser/files app you used to download the APKs.
5. Open Yelp Launcher and tap **OPEN JAVA ENGINE**. If Amethyst was not installed, the button opens its official release page instead.
6. In Amethyst, complete its Microsoft sign-in, manually choose Minecraft Java Edition 1.21.11, allow the engine to download its Java 21 runtime and game files, and press Play inside Amethyst. The version selected in Yelp is not automatically transferred yet.

The Amethyst APK contains its launcher and native graphics/audio/input components. Java 21 and Minecraft files are downloaded by Amethyst as needed. The first setup can be large and requires Wi-Fi/mobile data plus free storage. Use a Microsoft account that owns Minecraft: Java Edition. Never enter your Microsoft password into Yelp Launcher; sign in only on the Microsoft-hosted screen shown by the engine.

## What this does not yet do

Yelp Launcher does not send its selected version, account session, mod profile, or touch-layout JSON into Amethyst. Launching from Yelp opens the companion launcher home; the user completes game selection and launch there. The engine build runs in GitHub Actions, so the ZIP itself does not contain the engine APK.
