# Java Edition engine integration — 0.6.0-alpha

## Implemented in this milestone

Yelp Launcher now has a native Android bridge to open the Amethyst Java Edition engine companion when it is installed. Returning from the companion refreshes package status, so the home button changes from INSTALL to OPEN after installation. It checks the Amethyst debug and release package IDs using Android package visibility and launches the companion's own launcher Activity. If it is absent, the button opens Amethyst's official release page.

The Yelp UI does not collect Microsoft passwords or copy account tokens. Sign-in, Xbox/Minecraft authentication, entitlement checks, version installation, Java runtime selection, renderers, audio and game controls remain inside the Amethyst engine application.

## Why this is a companion, not embedded code

Amethyst Android is a full Android application with its own launcher Activities, services, native build, submodules and runtime assets. It is not published as an Android library/AAR. This release therefore builds it as a separately installable companion APK rather than pretending that the existing WebView app embeds its engine.

The GitHub Actions workflow builds two separate artifacts:

1. `Yelp-Launcher-0.6.0-alpha-debug-apk` — Yelp's original interface and native bridge.
2. `Yelp-Java-Engine-Amethyst-debug-apk` — Amethyst's Android Java Edition launcher and engine.

Install both APKs on the same Android device. The Yelp button will open Amethyst if it is installed. Inside Amethyst, sign in with Microsoft, choose/install the Minecraft version, then press Play there. Yelp's saved version selection is not automatically transferred to Amethyst in this milestone.

## Java runtimes

The workflow follows Amethyst's documented build approach and downloads its `jre8-pojav` CI artifact into the engine's runtime assets. The current Amethyst source also has a Java 17/21/25 runtime installer that downloads the matching architecture-specific runtime when a version requires it. For Minecraft 1.21.11, this supplies Java 21 on demand; it is not stored inside Yelp's WebView app.

## Upstream and licence notes

- Upstream source: https://github.com/AngelAuraMC/Amethyst-Android
- Source branch built by CI: `v3_openjdk` (workflow records the exact commit and submodule SHAs in the engine artifact).
- Amethyst project licence: LGPL-3.0.
- Its README lists additional dependencies with separate terms, including components with unknown or All-Rights-Reserved terms. The engine APK is built from upstream CI-compatible source rather than copied into this source archive. Review upstream notices and dependency terms before redistribution or public release.

## Known limits

- This is app-to-app handoff; it is not a single merged APK yet.
- Selecting a version in Yelp does not install or select it in Amethyst; select the same version inside Amethyst.
- Microsoft sign-in and ownership verification are performed by Amethyst, not Yelp.
- For Minecraft 1.21.11, first launch needs internet so Amethyst can download Java 21 through its runtime manager plus Minecraft assets and libraries.
- The engine companion APK build has been configured in CI but has not been run in this local container; no compiled engine APK is included in this source ZIP.
