#!/usr/bin/env sh
set -eu
ROOT="$(CDPATH= cd -- "$(dirname -- "$0")/.." && pwd)"
DEST="$ROOT/engine/Amethyst-Android"
if [ -e "$DEST/.git" ]; then
  echo "Amethyst source already exists at: $DEST"
  echo "Review its current branch, tags, submodules and licences before use."
  exit 0
fi
mkdir -p "$ROOT/engine"
git clone --depth 1 --branch v3_openjdk --recursive https://github.com/AngelAuraMC/Amethyst-Android.git "$DEST"
echo "Fetched upstream source to: $DEST"
echo "This is not yet integrated into Yelp Launcher. Audit licences and dependencies first."
