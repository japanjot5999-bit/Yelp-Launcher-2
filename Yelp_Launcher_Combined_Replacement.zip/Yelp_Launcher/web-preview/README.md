# Yelp Launcher browser preview

Open `index.html` in a modern browser. With an internet connection the preview fetches Mojang version metadata and Modrinth public project search results. Touch-control layouts and Replay Studio preferences are saved locally in browser storage.

The native Android app adds a restricted JSON bridge, MediaProjection screen recording, and an app-to-app handoff to the separately installed Amethyst Java Edition engine. The browser preview cannot open Android apps, request screen capture or launch Minecraft. Install the separate Android APKs and follow `docs/ENGINE_COMPANION_SETUP.md` to use the engine.
