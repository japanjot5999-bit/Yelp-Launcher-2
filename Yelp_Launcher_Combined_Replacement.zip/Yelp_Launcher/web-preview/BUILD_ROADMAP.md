# Yelp Launcher native roadmap

1. UI/catalogue and native screen recording milestone: completed in alpha 0.5.0.
2. Amethyst engine companion handoff and separate CI APK build: configured in alpha 0.6.0; first GitHub Actions build and phone installation still need verification.
3. Version/account adapter: transfer selected profile, account status and launch request from Yelp to the engine through a reviewed, documented interface.
4. Mod/pack manager: download, dependency resolution, loader/game-version validation, hash verification and safe per-instance installation.
5. Device input integration: bind Yelp touch layouts to engine controls and test hardware keyboard/mouse/gamepad profiles.
6. World Vault integration: import/export/backup via Android Storage Access Framework.
7. Replay Studio: game-state/event capture, independent camera, timeline/keyframes, audio policy and H.264 MP4 replay rendering.
8. Consider single-APK integration only after upstream architecture and all licence terms permit a maintainable merge.
9. Physical-device verification: ARM64 launch, runtime download, renderer, audio, input, mod loading, performance, thermals, suspend/resume and storage.
10. Measure real package size and optimize only after the end-to-end flow works; never pad packages.
