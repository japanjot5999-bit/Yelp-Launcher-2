# Alpha 0.4.0 source checks

Checks performed before packaging:
- `node --check web-preview/app.js` — passed.
- `node --check web-preview/service-worker.js` — passed.
- Static DOM ID/reference check — no missing `getElementById` targets.
- Android manifest and theme XML parse — passed.
- PWA manifest JSON parse — passed.
- Web preview and Android bundled assets — byte-for-byte matched.
- `MainActivity.java` syntax compile against temporary Android API stubs — passed. This does not replace a real Android SDK compilation.

Not run:
- Full Gradle/Android build: no Gradle binary or Android SDK is installed in the local build environment. The repository includes a GitHub Actions workflow for this step.
- Device install, game launch, game file download, mod installation, input binding and replay/MP4 recording: native game engine integration is not included yet.
