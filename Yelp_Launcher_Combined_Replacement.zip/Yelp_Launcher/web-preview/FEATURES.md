# Yelp Launcher alpha 0.6.0 — feature scope

- Original Android-first launcher hub with live Mojang and Modrinth metadata.
- Draggable touch-layout editor and local presets.
- Native Android H.264 MP4 screen recording (device display capture; not game-state replay).
- Native bridge to open the separately installed Amethyst Java Edition engine companion.
- GitHub Actions builds separate Yelp UI and Amethyst engine APKs.

The Amethyst companion supplies Java Edition engine, authentication, version installation, Java runtime management and game launching. The Yelp-selected version is not automatically transferred; select the same version in Amethyst. Yelp and the engine remain separate APKs in this alpha.
