# Offline-first bundle design

## Goal
The requested minimum target is **50 MB for a useful playable APK**, but only when that size comes from real, tested and redistributable components. Do not add filler or unrelated assets just to cross the threshold.

## Future APK components (after audit)
- Yelp Launcher native app and UI.
- Tested ARM64-compatible Java runtimes matched to supported Minecraft releases.
- Redistributable graphics/rendering backends and required native libraries.
- Native audio and input libraries.
- Checksums, component manifest, licence notices and corresponding source notices where required.

## Downloaded separately
- Minecraft proprietary game JARs, assets and libraries, acquired through official user sign-in and ownership checks.
- Third-party mods, shaders, resource packs and modpacks, downloaded from creator/provider sources after compatibility and licence checks.
- User worlds, backups and replay recordings.

## Device strategy
Start with arm64-v8a for the target Android phone. Add other ABIs only after testing; every extra ABI increases package size. If multiple Java runtimes or native renderers make one APK too large, use a verified optional runtime/engine expansion package instead of duplicating files.

## Current status
The current alpha contains no game engine, Java runtime or graphics backend, so its APK will be smaller than 50 MB and cannot play Minecraft. The 50 MB requirement is a target for the later playable build, not something this WebView-only milestone can honestly satisfy.
