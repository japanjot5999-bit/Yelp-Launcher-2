# Yelp Launcher Android project (0.4.0-alpha)

The Android project packages the original Yelp Launcher UI in a WebView. It includes a narrow asynchronous JSON bridge for the official Mojang version manifest and Modrinth API. The bridge only accepts HTTPS requests to the approved metadata hosts and limits response size.

## Current status

This is **not yet a playable Minecraft Java launcher**. The following are not implemented:
- Amethyst/Java Edition game-engine integration.
- Microsoft/Xbox/Minecraft Services sign-in and Java ownership verification.
- Actual Minecraft version download/install and repair pipeline.
- Java runtime and graphics/audio/input native bundles.
- Mod/modpack installation into a game instance (the current UI is a live browser only).
- Native touch/keyboard/controller input binding.
- Replay data capture, camera playback and MP4 export.

## Build

Requirements: Android SDK Platform 36, Build Tools 36.0.0, JDK 17, Android Gradle Plugin 9.4.1 and Gradle 9.6.0.

```sh
./gradlew assembleDebug
```

A GitHub Actions workflow at `.github/workflows/android-debug.yml` builds the current debug APK and uploads it as an artifact. The workflow reports the measured APK size; it does not inflate the app with dummy data. A 50 MB playable build requires the real engine/runtime/native integration first.

## Phone-only note

Termux alone does not automatically provide a complete Android SDK/NDK build toolchain. The repository includes a cloud GitHub Actions build workflow so the current source shell can be compiled without installing Android Studio on the phone. A successful shell build is not evidence that Minecraft launches.

## Security

The app only requests internet access. The JavaScript bridge permits HTTPS GET requests only to Mojang metadata and Modrinth API hosts. It does not expose arbitrary file access, arbitrary HTTP access or Microsoft credentials. Future Microsoft sign-in must use the official browser-based OAuth authorization-code flow with PKCE and Android Keystore-backed credential storage.


## 0.6.0-alpha Java engine companion

The main Android app detects and opens the separately installed Amethyst Android package. It does not bundle Amethyst inside this app. The GitHub Actions workflow builds the Yelp APK and Amethyst engine APK as separate artifacts. Install both to use the native Java Edition engine; complete Microsoft sign-in and Minecraft installation in Amethyst itself. Java 21 runtime installation is handled by Amethyst when a 1.21.11 profile is launched. See `../docs/ENGINE_COMPANION_SETUP.md`.
