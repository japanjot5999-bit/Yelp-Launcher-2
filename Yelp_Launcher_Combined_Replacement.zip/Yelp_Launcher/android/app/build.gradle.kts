plugins {
    id("com.android.application")
}

android {
    namespace = "com.yelp.launcher"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.yelp.launcher"
        minSdk = 26
        targetSdk = 36
        versionCode = 5
        versionName = "0.6.0-alpha"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildTypes {
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
}
