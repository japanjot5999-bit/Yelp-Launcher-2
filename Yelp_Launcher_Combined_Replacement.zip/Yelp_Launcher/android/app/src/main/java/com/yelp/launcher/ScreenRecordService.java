package com.yelp.launcher;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.ContentValues;
import android.content.Intent;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.media.MediaRecorder;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.net.Uri;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;

import java.io.File;
import java.io.FileInputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** User-consented Android display capture to H.264 MP4. This is screen recording,
 * not deterministic Minecraft replay data; replay-camera rendering needs the game engine hook.
 */
public final class ScreenRecordService extends Service {
    public static final String ACTION_START = "com.yelp.launcher.RECORD_START";
    public static final String ACTION_STOP = "com.yelp.launcher.RECORD_STOP";
    public static final String ACTION_STATE = "com.yelp.launcher.RECORD_STATE";
    private static final String CHANNEL = "yelp_screen_recording";
    private MediaProjection projection;
    private MediaRecorder recorder;
    private VirtualDisplay display;
    private File output;
    private boolean started;
    private String requestedResolution = "1280 x 720";
    private int requestedFps = 30;
    private String requestedQuality = "Balanced";

    @Override public void onCreate() {
        super.onCreate();
        NotificationChannel channel = new NotificationChannel(CHANNEL, "Screen recording", NotificationManager.IMPORTANCE_LOW);
        getSystemService(NotificationManager.class).createNotificationChannel(channel);
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) { stopSelf(); return START_NOT_STICKY; }
        if (ACTION_STOP.equals(intent.getAction())) { stopRecording(); return START_NOT_STICKY; }
        if (ACTION_START.equals(intent.getAction())) {
            startForeground(41, new Notification.Builder(this, CHANNEL)
                    .setContentTitle("Yelp Launcher recording")
                    .setContentText("Recording the screen to MP4. Tap Stop in Replay Studio to finish.")
                    .setSmallIcon(android.R.drawable.presence_video_online)
                    .setOngoing(true).build());
            int resultCode = intent.getIntExtra("resultCode", 0);
            requestedResolution = intent.getStringExtra("resolution") == null ? "1280 x 720" : intent.getStringExtra("resolution");
            requestedFps = intent.getIntExtra("fps", 30);
            requestedQuality = intent.getStringExtra("quality") == null ? "Balanced" : intent.getStringExtra("quality");
            Intent data = intent.getParcelableExtra("resultData");
            try { beginRecording(resultCode, data); }
            catch (Exception e) { sendState(false, "Recording failed: " + e.getMessage()); stopSelf(); }
        }
        return START_NOT_STICKY;
    }

    private String intentResolutionFallback() { return requestedResolution; }
    private int getIntentFpsFallback() { return Math.max(24, Math.min(60, requestedFps)); }
    private String getIntentQualityFallback() { return requestedQuality; }

    private void beginRecording(int resultCode, Intent data) throws Exception {
        if (data == null) throw new IllegalArgumentException("Screen capture permission was not supplied");
        MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        projection = manager.getMediaProjection(resultCode, data);
        if (projection == null) throw new IllegalStateException("Android did not grant screen capture");
        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() { if (started) stopRecording(); }
        }, new Handler(Looper.getMainLooper()));
        int displayWidth = getResources().getDisplayMetrics().widthPixels;
        int displayHeight = getResources().getDisplayMetrics().heightPixels;
        int density = getResources().getDisplayMetrics().densityDpi;
        String resolution = intentResolutionFallback();
        String[] dimensions = resolution.toLowerCase(Locale.US).split("x");
        int requestedWidth = displayWidth, requestedHeight = displayHeight;
        try { requestedWidth = Integer.parseInt(dimensions[0].trim()); requestedHeight = Integer.parseInt(dimensions[1].trim()); }
        catch (Exception ignored) { }
        // Preserve the phone's screen aspect ratio; selected dimensions are maximum bounds, never upscaled.
        double scale = Math.min(1.0, Math.min((double) requestedWidth / displayWidth, (double) requestedHeight / displayHeight));
        int width = Math.max(2, ((int) (displayWidth * scale)) & ~1);
        int height = Math.max(2, ((int) (displayHeight * scale)) & ~1);
        int fps = getIntentFpsFallback();
        String quality = getIntentQualityFallback();
        int bitrate = "Compact".equalsIgnoreCase(quality) ? 3_000_000 : "High".equalsIgnoreCase(quality) ? 10_000_000 : "Ultra".equalsIgnoreCase(quality) ? 14_000_000 : 6_000_000;
        File appMovies = getExternalFilesDir(Environment.DIRECTORY_MOVIES);
        if (appMovies == null) throw new IllegalStateException("App storage is unavailable");
        File dir = new File(appMovies, "YelpLauncher");
        if (!dir.exists() && !dir.mkdirs()) throw new IllegalStateException("Cannot create recording folder");
        String stamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(new Date());
        output = new File(dir, "YelpReplayCapture_" + stamp + ".mp4");
        recorder = Build.VERSION.SDK_INT >= 31 ? new MediaRecorder(this) : new MediaRecorder();
        recorder.setVideoSource(MediaRecorder.VideoSource.SURFACE);
        recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4);
        recorder.setVideoEncoder(MediaRecorder.VideoEncoder.H264);
        recorder.setVideoSize(width, height);
        recorder.setVideoFrameRate(fps);
        recorder.setVideoEncodingBitRate(bitrate);
        recorder.setOutputFile(output.getAbsolutePath());
        recorder.prepare();
        display = projection.createVirtualDisplay("YelpLauncher-MP4", width, height, density,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, recorder.getSurface(), null, null);
        recorder.start();
        started = true;
        sendState(true, "Screen recording active · H.264 MP4 · " + fps + " FPS · " + width + "×" + height);
    }

    private void stopRecording() {
        try {
            if (recorder != null && started) recorder.stop();
        } catch (RuntimeException ignored) {
            if (output != null) output.delete();
        }
        started = false;
        if (display != null) { display.release(); display = null; }
        if (recorder != null) { try { recorder.reset(); } catch (Exception ignored) {} recorder.release(); recorder = null; }
        if (projection != null) { projection.stop(); projection = null; }
        String message = "Recording stopped";
        if (output != null && output.exists() && output.length() > 1024) {
            try { Uri saved = publishToMovies(output); message = "MP4 saved to Movies/YelpLauncher · " + saved; }
            catch (Exception e) { message = "MP4 saved in app Movies folder; gallery copy failed: " + e.getMessage(); }
        } else if (output != null) { output.delete(); message = "Recording was too short; no MP4 was saved"; }
        sendState(false, message);
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private Uri publishToMovies(File source) throws Exception {
        if (Build.VERSION.SDK_INT < 29) return Uri.fromFile(source);
        ContentValues values = new ContentValues();
        values.put(MediaStore.Video.Media.DISPLAY_NAME, source.getName());
        values.put(MediaStore.Video.Media.MIME_TYPE, "video/mp4");
        values.put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/YelpLauncher");
        values.put(MediaStore.Video.Media.IS_PENDING, 1);
        Uri uri = getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values);
        if (uri == null) throw new IllegalStateException("Could not create MP4 in Movies");
        try (FileInputStream in = new FileInputStream(source); OutputStream out = getContentResolver().openOutputStream(uri)) {
            if (out == null) throw new IllegalStateException("Could not open MP4 destination");
            byte[] buffer = new byte[64 * 1024]; int count;
            while ((count = in.read(buffer)) != -1) out.write(buffer, 0, count);
        }
        ContentValues ready = new ContentValues(); ready.put(MediaStore.Video.Media.IS_PENDING, 0);
        getContentResolver().update(uri, ready, null, null);
        source.delete();
        return uri;
    }

    private void sendState(boolean recording, String message) {
        Intent event = new Intent(ACTION_STATE); event.setPackage(getPackageName());
        event.putExtra("recording", recording); event.putExtra("message", message); sendBroadcast(event);
    }

    @Override public void onDestroy() {
        if (started) stopRecording();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
