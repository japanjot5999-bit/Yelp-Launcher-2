package com.yelp.launcher;

import android.app.Activity;
import android.media.projection.MediaProjectionManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.IntentFilter;
import android.os.Build;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;
import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URI;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Yelp Launcher Android shell with a restricted JSON network bridge.
 * The Java Edition engine is not yet embedded; this Activity hosts the launcher UI.
 */
public final class MainActivity extends Activity {
    private WebView webView;
    private final ExecutorService networkExecutor = Executors.newFixedThreadPool(3);
    private static final int MAX_RESPONSE_BYTES = 4 * 1024 * 1024;
    private static final int REQUEST_SCREEN_CAPTURE = 7401;
    private boolean receiverRegistered = false;
    private String captureResolution = "1280 x 720";
    private int captureFps = 30;
    private String captureQuality = "Balanced";
    private final BroadcastReceiver recordingReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (webView == null) return;
            boolean active = intent.getBooleanExtra("recording", false);
            String message = intent.getStringExtra("message");
            webView.evaluateJavascript("window.onNativeRecordingState && window.onNativeRecordingState(" + active + "," + JSONObject.quote(message == null ? "" : message) + ");", null);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(16, 23, 32));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(16, 23, 32));
        webView = new WebView(this);
        webView.setBackgroundColor(android.graphics.Color.rgb(16, 23, 32));
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSupportMultipleWindows(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(false);
        webView.addJavascriptInterface(new LauncherBridge(), "AndroidLauncher");
        webView.setWebChromeClient(new WebChromeClient());
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return routeUrl(request.getUrl()); }
            @SuppressWarnings("deprecation") @Override public boolean shouldOverrideUrlLoading(WebView view, String url) { return routeUrl(Uri.parse(url)); }
        });
        setContentView(webView);
        IntentFilter filter = new IntentFilter(ScreenRecordService.ACTION_STATE);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(recordingReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(recordingReceiver, filter);
        receiverRegistered = true;
        webView.loadUrl("file:///android_asset/index.html");
    }

    private final class LauncherBridge {
        @JavascriptInterface public void startScreenRecording(String resolution, String fps, String quality) {
            captureResolution = resolution == null ? "1280 x 720" : resolution.replace('×', 'x');
            try { captureFps = Math.max(24, Math.min(60, Integer.parseInt(fps.replaceAll("[^0-9]", "")))); }
            catch (Exception ignored) { captureFps = 30; }
            captureQuality = quality == null ? "Balanced" : quality;
            runOnUiThread(() -> {
                MediaProjectionManager manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
                startActivityForResult(manager.createScreenCaptureIntent(), REQUEST_SCREEN_CAPTURE);
            });
        }
        @JavascriptInterface public void stopScreenRecording() {
            Intent stop = new Intent(MainActivity.this, ScreenRecordService.class);
            stop.setAction(ScreenRecordService.ACTION_STOP);
            startService(stop);
        }
        @JavascriptInterface public void openSavedVideos() {
            runOnUiThread(() -> {
                Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                pick.addCategory(Intent.CATEGORY_OPENABLE);
                pick.setType("video/mp4");
                startActivityForResult(pick, 7402);
            });
        }
        /** Returns whether the separately installed Amethyst Java engine can be opened. */
        @JavascriptInterface public String javaEngineStatus() {
            if (getPackageManager().getLaunchIntentForPackage("org.angelauramc.amethyst.debug") != null) return "installed-debug";
            if (getPackageManager().getLaunchIntentForPackage("org.angelauramc.amethyst") != null) return "installed-release";
            return "missing";
        }

        /** Opens the Java Edition engine companion; authentication and game selection happen there. */
        @JavascriptInterface public void openJavaEngine(String requestedVersion) {
            runOnUiThread(() -> {
                Intent launch = getPackageManager().getLaunchIntentForPackage("org.angelauramc.amethyst.debug");
                if (launch == null) launch = getPackageManager().getLaunchIntentForPackage("org.angelauramc.amethyst");
                if (launch != null) {
                    launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    try {
                        startActivity(launch);
                        Toast.makeText(MainActivity.this,
                                "Java engine opened. Sign in, select and install " + safeVersionLabel(requestedVersion) + ", then press Play in the engine.",
                                Toast.LENGTH_LONG).show();
                    } catch (ActivityNotFoundException e) {
                        Toast.makeText(MainActivity.this, "The installed Java engine could not be opened.", Toast.LENGTH_LONG).show();
                    }
                    return;
                }
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW,
                            Uri.parse("https://github.com/AngelAuraMC/Amethyst-Android/releases")));
                } catch (ActivityNotFoundException e) {
                    Toast.makeText(MainActivity.this, "Install the Amethyst Java engine companion first.", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface public void fetchJson(String requestId, String rawUrl) {
            if (requestId == null || requestId.length() > 40 || rawUrl == null || rawUrl.length() > 4096) return;
            final String id = requestId;
            final String address = rawUrl;
            networkExecutor.execute(() -> {
                String result = null; String error = null;
                try { result = fetchAllowedJson(address); }
                catch (Exception e) { error = e.getMessage() == null ? "Network request failed" : e.getMessage(); }
                final String response = result; final String failure = error;
                runOnUiThread(() -> {
                    if (webView == null) return;
                    String script = "window.onNativeFetchResult && window.onNativeFetchResult(" + JSONObject.quote(id) + "," + (failure == null ? JSONObject.quote(response) : "null") + "," + (failure == null ? "null" : JSONObject.quote(failure)) + ");";
                    webView.evaluateJavascript(script, null);
                });
            });
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 7402) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                Intent view = new Intent(Intent.ACTION_VIEW);
                view.setDataAndType(data.getData(), "video/mp4");
                view.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                try { startActivity(view); } catch (ActivityNotFoundException e) { Toast.makeText(this, "No video player is available.", Toast.LENGTH_SHORT).show(); }
            }
            return;
        }
        if (requestCode == REQUEST_SCREEN_CAPTURE) {
            if (resultCode == RESULT_OK && data != null) {
                Intent start = new Intent(this, ScreenRecordService.class);
                start.setAction(ScreenRecordService.ACTION_START);
                start.putExtra("resultCode", resultCode);
                start.putExtra("resultData", data);
                start.putExtra("resolution", captureResolution);
                start.putExtra("fps", captureFps);
                start.putExtra("quality", captureQuality);
                if (Build.VERSION.SDK_INT >= 26) startForegroundService(start); else startService(start);
            } else if (webView != null) {
                webView.evaluateJavascript("window.onNativeRecordingState && window.onNativeRecordingState(false,'Screen capture permission was cancelled')", null);
            }
        }
    }

    private static String safeVersionLabel(String value) {
        if (value == null || !value.matches("[0-9A-Za-z._-]{1,40}")) return "your selected version";
        return "Minecraft " + value;
    }

    private String fetchAllowedJson(String rawUrl) throws Exception {
        URI uri = URI.create(rawUrl);
        String host = uri.getHost();
        if (!"https".equalsIgnoreCase(uri.getScheme()) || host == null ||
                !(host.equalsIgnoreCase("piston-meta.mojang.com") || host.equalsIgnoreCase("launchermeta.mojang.com") || host.equalsIgnoreCase("api.modrinth.com")) || (uri.getPort() != -1 && uri.getPort() != 443) || uri.getUserInfo() != null) {
            throw new SecurityException("This network host is not allowed.");
        }
        HttpURLConnection connection = (HttpURLConnection) new URL(rawUrl).openConnection();
        connection.setRequestMethod("GET");
        connection.setConnectTimeout(12000);
        connection.setReadTimeout(18000);
        connection.setInstanceFollowRedirects(false);
        connection.setRequestProperty("Accept", "application/json");
        connection.setRequestProperty("User-Agent", "YelpLauncher/0.6.0-alpha (Android launcher metadata client)");
        try {
            int status = connection.getResponseCode();
            if (status < 200 || status >= 300) throw new java.io.IOException("Server returned HTTP " + status);
            try (InputStream in = connection.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                byte[] buffer = new byte[8192]; int read;
                while ((read = in.read(buffer)) != -1) {
                    if (out.size() + read > MAX_RESPONSE_BYTES) throw new java.io.IOException("JSON response is too large");
                    out.write(buffer, 0, read);
                }
                String json = out.toString("UTF-8");
                new JSONObject(json); // Validate that the endpoint returned a JSON object.
                return json;
            }
        } finally { connection.disconnect(); }
    }

    private boolean routeUrl(Uri uri) {
        String scheme = uri.getScheme() == null ? "" : uri.getScheme();
        if ("file".equalsIgnoreCase(scheme) || "about".equalsIgnoreCase(scheme)) return false;
        if ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme)) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
            catch (ActivityNotFoundException e) { Toast.makeText(this, "No browser is available to open this link.", Toast.LENGTH_SHORT).show(); }
            return true;
        }
        return true;
    }

    @Override protected void onResume() {
        super.onResume();
        // The user may have installed or updated Amethyst while Yelp was backgrounded.
        // Recheck package visibility after returning to this Activity.
        if (webView != null) {
            webView.post(() -> webView.evaluateJavascript(
                    "if (window.refreshJavaEngineStatus) window.refreshJavaEngineStatus();", null));
        }
    }

    @Override @SuppressWarnings("deprecation") public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() {
        networkExecutor.shutdownNow();
        if (receiverRegistered) { try { unregisterReceiver(recordingReceiver); } catch (Exception ignored) {} receiverRegistered = false; }
        if (webView != null) { webView.stopLoading(); webView.loadUrl("about:blank"); webView.destroy(); webView = null; }
        super.onDestroy();
    }
}
