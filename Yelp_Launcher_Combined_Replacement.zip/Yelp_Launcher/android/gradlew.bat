@echo off
setlocal
set ROOT=%~dp0
set VERSION=9.6.0
set DIST=%ROOT%.gradle-bootstrap\gradle-%VERSION%
if exist "%DIST%\bin\gradle.bat" goto run
where gradle >NUL 2>NUL
if %ERRORLEVEL%==0 goto systemgradle
echo Please install Gradle %VERSION% or run this project from Android Studio.
exit /b 1
:systemgradle
gradle %*
exit /b %ERRORLEVEL%
:run
"%DIST%\bin\gradle.bat" %*
exit /b %ERRORLEVEL%
