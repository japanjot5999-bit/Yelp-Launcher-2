# Changelog

## 0.4.0-alpha — 2026-11-22
- Live Mojang version catalogue and selected-version profile persistence.
- Modrinth online catalogues for mods, modpacks, resource packs, shaders and data packs.
- Android network bridge restricted to Mojang metadata and Modrinth API HTTPS hosts.
- Draggable/savable mobile control layout editor.
- Replay Studio MP4-only export settings and native integration status.
- Added engine/replay integration documents and CI Android build workflow.
- No playable engine, runtime, game files or actual replay capture in this release.


## 0.5.0-alpha — Native MP4 capture
- Connected Replay Studio to Android MediaProjection consent and a foreground recording service.
- Added silent H.264 MP4 screen capture with selectable maximum resolution, frame rate and quality target.
- Added save-to-Movies/YelpLauncher and an Android MP4 picker.
- Clarified that this is screen capture, not game-state replay.
- Minecraft Java engine integration and in-app game launch remain pending.


## 0.6.0-alpha — Java engine companion handoff
- Added native package detection and launch handoff to the Amethyst Java Edition engine companion.
- Added missing-engine fallback to Amethyst's official releases page.
- Added Android package-visibility declarations.
- Added a GitHub Actions job that builds and uploads a separate Amethyst engine APK with recursive submodules and its documented JRE 8 artifact.
- Documented Java 17/21 runtime auto-installation, Microsoft sign-in and game launch through the companion.
- Clarified that Yelp and the engine are separate APKs and version/account synchronization is not implemented.
