YELP LAUNCHER SOURCE PACKAGE

This ZIP contains the Yelp Launcher Android app source and matching web-preview source.
It is source code, not an APK.

To build it with GitHub Actions, the repository also needs the build workflow from the
separate Java Engine Build Kit ZIP (or a matching Yelp-only workflow). The original
combined workflow is available in the original complete source ZIP.

The Yelp app and Java engine companion are separate Android apps/APKs.

This package includes its own GitHub Actions workflow at
.github/workflows/android-launcher.yml. Its artifact name is
Yelp-Launcher-0.6.0-alpha-debug-apk.
