# Third-party notices

This alpha contains the original Yelp Launcher UI and Android WebView shell. It does not bundle Minecraft game files, third-party mod JARs, modpack files, shaders, resource packs, Java runtimes, graphics drivers, Amethyst engine code, ReplayMod code or FFmpeg binaries.

## Live metadata services
- Mojang version manifest: used to display public Minecraft Java version metadata.
- Modrinth API: used to discover public creator projects. Project files remain on Modrinth/creator pages; each project's own licence and compatibility terms apply.

## Engine candidates
Amethyst Android is referenced only as a potential engine integration. It is not included in this archive. Review the upstream LGPL licence, notices, submodules and each transitive/native dependency licence before use or redistribution.

## Replay reference
ReplayMod's GitHub repository identifies its licence as GPL-3.0. This project does not copy its source or assets. Any later adaptation or distribution of GPL-covered code must meet the licence terms and provide corresponding source as required.

## Minecraft
Minecraft is proprietary software. The launcher must retrieve game files through the official metadata/download process after appropriate Microsoft sign-in and Java ownership checks; no proprietary Minecraft files are bundled here.


## Java Edition engine companion (built separately by CI)

Yelp Launcher 0.6.0-alpha invokes the Amethyst Android companion if installed. Amethyst is not vendored or linked as a library in this source archive. The companion APK is built from the public upstream source repository at https://github.com/AngelAuraMC/Amethyst-Android and is licensed by that project under LGPL-3.0. Its README lists a mix of component licences, including GPL/LGPL, MIT, BSD-3-Clause, Apache-2.0, zlib, unknown terms and All-Rights-Reserved components. Audit the complete upstream submodule and dependency notices before redistribution. The CI artifact includes the upstream commit/submodule metadata and top-level Amethyst licence copy.
