# Yelp Launcher feature inventory — alpha 0.6.0

## Implemented in the current source
- Original Android-first navy/teal/mint interface; English only.
- Android WebView shell with a restricted native JSON bridge to Mojang metadata and Modrinth API.
- Live Mojang version catalogue: releases, snapshots, old beta and old alpha; search, pagination and selected-profile persistence.
- Modrinth discovery for mods, modpacks, resource packs, shaders and data packs; game-version and loader filters; creator metadata and project-page links.
- Draggable/resizable touch-control editor with presets and local saving. These layouts are not yet bound to the engine's controls.
- Native Android H.264 MP4 screen capture with user consent, a foreground service and saved-video access. It records the display, not game-state replay.
- Native package detection and app-to-app launch handoff to Amethyst Android. Missing-engine fallback opens the official Amethyst releases page.
- GitHub Actions job that builds a separate Amethyst engine companion APK from upstream source with recursive submodules and the documented JRE 8 CI runtime artifact.

## Provided by the separately installed Amethyst companion
- Minecraft Java Edition game engine, renderer, native audio/input components and game-version installation.
- Microsoft sign-in and Minecraft account/profile/entitlement flow.
- Java runtime selection and on-demand Java 17/21/25 runtime downloads when required.
- Minecraft game launch, mobile controls, keyboard/mouse and gamepad support within the engine.
- Forge/Fabric support as documented by upstream.

## Not yet connected between Yelp and engine
- Automatic transfer of the selected version from Yelp to Amethyst.
- Shared Microsoft account/session state; Yelp intentionally does not read or store engine tokens.
- Installation of Modrinth mods/modpacks directly into the engine instance.
- Binding Yelp's custom touch layouts to engine input.
- World Vault import/export/backup integration.
- ReplayMod-like game-state capture, free-camera timeline and MP4 replay rendering.
- One merged APK containing both Yelp UI and Amethyst engine.

## Build status and guardrails
- The CI workflow builds two separate APK artifacts. Its Amethyst build and the on-device launch have not been run in this local environment.
- Amethyst is LGPL-3.0 and lists transitive dependencies with separate licence terms. Audit the exact source/submodule commit and licence inventory before redistribution.
- Never collect Microsoft passwords or embed a client secret in Yelp.
- Never bypass Minecraft Java ownership checks or bundle proprietary Minecraft game files.
- Never auto-install unchecked executable/mod files. Attribute creators and display each project's licence.
