# Yelp Launcher — Android-first alpha 0.6.0

Yelp Launcher is an original Android-first Minecraft Java Edition hub. Version 0.6.0-alpha adds a native Android handoff to the Amethyst Java engine companion. The handoff is source-checked but still requires a GitHub Actions build and phone test. It is a **two-APK setup**, not yet one merged app: install the Yelp interface APK and the engine companion APK, then launch Amethyst from Yelp.

## Included in the current alpha
- Android WebView shell with a restricted native JSON bridge (Mojang version manifest and Modrinth API hosts only).
- Live Mojang Java version catalogue: releases, snapshots, old beta and old alpha, with search and saved selected profile.
- Modrinth catalogue search for mods, modpacks, resource packs, shaders and data packs; game-version and loader filters; creator pages.
- Touch layout editor with draggable control buttons, size slider, preset layouts and local save.
- Replay Studio with native Android H.264 MP4 screen capture and a saved-video picker. This is display recording, not a full game-state replay renderer.
- World vault, settings, download/runtime integration roadmap and Discord community link.

## How Minecraft launch works now
The Yelp APK remains the UI shell. Its native Android bridge checks for the Amethyst engine package and opens it; if it is missing, the button opens Amethyst's official releases page. A separate GitHub Actions job builds an Amethyst engine companion APK from its public source with recursive submodules and the JRE 8 artifact used by its upstream build workflow. Amethyst provides the Java Edition engine, Microsoft sign-in UI, game-version installer, Java runtime manager, renderer/audio/input components and Minecraft launch flow. Current upstream notes list Java 17/21/25 as downloadable runtimes, so a first 1.21.11 launch needs internet to install Java 21. Complete sign-in, select and install the same version manually in Amethyst, then press Play there. Yelp does not yet sync the account or version selection into the engine.

## Why the APK is not padded to 50 MB
The engine APK should be much larger than the small Yelp UI APK because it contains real native code and runtime support. CI reports the actual size of each artifact; no filler is added. Java 8 is bundled via the Amethyst CI runtime artifact, while Java 17/21/25 are supported by Amethyst's runtime manager and downloaded for the required Minecraft version when needed. The 50 MB threshold is not asserted until CI produces the actual APK and reports its size.

## Mods and packs
The catalogues use Modrinth's public search API. This does not mean every mod or modpack exists for every game version. The launcher displays creator-provided compatibility metadata and links to the project page. A native installer still needs to resolve dependencies, check loaders/game versions, validate hashes, apply licences and write into a user-selected instance directory. It must not silently install arbitrary files.

## Replay Studio
Replay Studio records the Android device display to H.264 MP4 after Android's screen-capture consent. It is silent screen recording, not true ReplayMod-style game-state capture with independent cameras, timeline/keyframes or replay rendering. The upstream ReplayMod source is GPL-3.0; this project does not copy its source code or assets.

## Build and retrieve the debug APK

See `docs/ENGINE_COMPANION_SETUP.md`. The workflow `.github/workflows/android-debug.yml` builds two artifacts in parallel:
1. `Yelp-Launcher-0.6.0-alpha-debug-apk` — the Yelp interface APK.
2. `Yelp-Java-Engine-Amethyst-debug-apk` — the Amethyst engine companion APK, built with native components and the JRE 8 CI runtime bundle. Java 21 remains a first-run runtime-manager download.

Install both APKs on the same Android phone. Open Yelp and tap **OPEN JAVA ENGINE**. Sign in, select/install Minecraft 1.21.11 in Amethyst, let it install Java 21 and game files when required, then press Play inside Amethyst. The version selected in Yelp is not automatically transferred yet.

Amethyst is LGPL-3.0 and has separate dependency notices; review upstream notices and submodule licences before redistribution. The engine build job has been configured but must be run in GitHub Actions before the engine APK is available. The workflow prints actual APK sizes; it does not pad packages.


## 0.5.0 alpha — native MP4 screen capture

Replay Studio now starts Android MediaProjection after explicit system consent and records the device display as H.264 MP4 using a foreground media-projection service. Finished MP4 files are copied to `Movies/YelpLauncher` on Android 10+. The capture is silent (no microphone/audio capture) and is a screen recording, not a deterministic game replay. It can capture a running game only after that game is running on the device.

True ReplayMod-style functionality (game-state/event capture, independent spectator camera, timeline/keyframes and rendering) is not implemented because the engine does not expose a Yelp replay adapter. Minecraft can be launched through the separately installed Amethyst engine companion; it is not yet a single merged APK.


## 0.6.0-alpha: Java Edition engine companion

This release adds a native Android handoff from Yelp Launcher to the Amethyst Java Edition engine companion. It does not falsely claim that the engine is embedded into the Yelp UI APK. GitHub Actions now builds two APK artifacts: the Yelp interface app and the Amethyst engine app. Install both; Yelp opens Amethyst when you tap the launch button. Sign in, install Minecraft 1.21.11 and press Play inside Amethyst. Setup steps: `docs/ENGINE_COMPANION_SETUP.md`.

The engine workflow clones Amethyst with recursive submodules and follows its published build process. It adds the upstream `jre8-pojav` runtime artifact; Java 21 is installed on demand by the engine when required by Minecraft 1.21.11. The workflow records the exact upstream commit and submodule SHAs.

**Not yet a merged single APK:** selected profile, account, installed modpacks and touch layout are not synced from Yelp into Amethyst. The two APKs must be installed separately. The engine workflow is configured but has not yet been executed in this local environment.
