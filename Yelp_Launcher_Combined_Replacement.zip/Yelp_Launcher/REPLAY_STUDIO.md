# Replay Studio — implementation specification

## Product target
An original built-in replay feature for Yelp Launcher, using only MP4/H.264 as the user-facing export format. The aim is comparable replay-editing workflows, not a literal source-code or asset copy of ReplayMod.

## Planned capabilities
- Session capture toggle and recording indicator.
- Replay index, thumbnails, metadata and world/session association.
- Timeline scrubber, playback speed, pause/resume and event markers.
- Spectator camera, camera roll, position/time/spectator keyframes and interpolation.
- Resolution, frame-rate and quality presets with thermal-aware limits.
- H.264 MP4 encoding, progress, cancel/resume policy and export via Android Storage Access Framework.
- Disk-space estimate and preflight warning before rendering.

## Native architecture required
1. A version/loader-compatible game hook records replay events and required world/entity state.
2. A deterministic playback controller feeds events into the matching client renderer.
3. Camera spline/keyframe evaluation drives spectator frames.
4. Frame capture feeds a licensed/redistributable native encoder or FFmpeg-compatible pipeline.
5. Audio capture/mix and sync are handled separately, with permission and privacy controls.
6. MP4 export writes to a user-selected destination and cleans temporary frames after success/cancel.

## Current state
Only the settings/UI and local preference storage exist. No game events, frames, replay files or MP4 videos are captured in 0.4.0.

## Licence note
ReplayMod's public repository identifies GPL-3.0 licensing. This implementation does not include ReplayMod source. If future work adapts its GPL code, retain notices, comply with GPL requirements and distribute the corresponding source for covered binaries.


## Implemented in 0.5.0 alpha
- Android MediaProjection consent flow.
- Foreground media-projection service with H.264 MP4 encoding at the device display size, 30 FPS and a 6 Mbps target bitrate.
- MP4 output is published to `Movies/YelpLauncher` through MediaStore on Android 10+.
- Saved MP4 selection can be opened using Android's document picker.
- Screen capture is silent and records the display; it is not game-state replay.

## Still blocked on engine integration
- Replay data/event capture and deterministic playback.
- Free spectator camera, camera keyframes and replay timeline rendering.
- Replay render-to-MP4 pipeline from the game renderer.
