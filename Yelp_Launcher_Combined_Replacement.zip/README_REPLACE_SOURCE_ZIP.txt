YELP LAUNCHER — COMBINED SOURCE REPLACEMENT BUNDLE
==================================================

This bundle combines the original Yelp_Launcher source folder with the
Java Engine Build Kit ZIP and the Yelp Launcher Update Patch ZIP.

CONTENTS AT THE ARCHIVE ROOT
----------------------------
Yelp_Launcher/                    Original launcher source project
Yelp_Java_Engine_Build_Kit.zip    Original Amethyst engine build kit
Yelp_Launcher_Update_Patch.zip   Direct-play + Modrinth + 20 collections update

HOW TO USE IN THE EXISTING GITHUB REPOSITORY
--------------------------------------------
1. Upload this archive to the repository root using the exact filename:
   Yelp_Launcher_Source.zip
   Replace the previous Yelp_Launcher_Source.zip.
2. Keep the separate Yelp_Java_Engine_Build_Kit.zip already in the repository
   for now. The combined archive also carries a copy so the inputs stay together.
3. The update patch is NOT automatically applied by the old workflow. Follow
   Yelp_Launcher_Update_Patch.zip -> Yelp_Launcher_Update_Patch/WORKFLOW_INSERT.txt
   and add its patch step to .github/workflows/build-both.yml.
4. The repository's existing workflow must be repaired if it still has the
   previously reported incomplete shell loop. Do not run a build until the
   workflow YAML is saved and its shell steps are complete.

IMPORTANT
---------
This is a combined source bundle, not an APK. It has not been built or tested
on an Android device. The patch is a build-time integration layer; its presence
inside this ZIP alone does not activate it. Keep a backup of the old ZIP and
workflow until GitHub Actions completes successfully.
